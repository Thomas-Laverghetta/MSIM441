/// \struct TextureCoord
/// Structure for storing 2D texture coordinates

struct TextureCoord {
	float u;
	float v;
};