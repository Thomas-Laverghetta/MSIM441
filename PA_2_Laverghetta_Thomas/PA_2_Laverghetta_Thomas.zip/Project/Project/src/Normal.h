struct Normal {
	float x;
	float y;
	float z;
};