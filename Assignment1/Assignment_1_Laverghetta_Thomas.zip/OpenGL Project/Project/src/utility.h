#pragma once
#include <string>
#include <gl/glut.h>

using namespace std;

void printString(string str);